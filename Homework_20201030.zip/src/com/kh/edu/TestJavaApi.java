package com.kh.edu;

import java.util.Date;
import java.text.SimpleDateFormat;

public class TestJavaApi {
	
	public static void main(String[] args) {
		
		Date date = new Date();
	
		SimpleDateFormat change =new SimpleDateFormat("yyyy/MM/dd");
		
		System.out.println(change.format(date));
	}
	
	
}

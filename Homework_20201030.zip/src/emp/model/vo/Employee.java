package emp.model.vo;

public class Employee {
	public void printEmpolyee() {
		System.out.println("Name: 강준혁\nAge: 27\nBirthDay:1994/06/06");
	}
}

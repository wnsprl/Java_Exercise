package product.model.vo;

public class Product {
	
	public void printProduct() {
		System.out.println("Product: TV\nSpecification: 42 inch\nPrice: 100 만원");	
	}
}

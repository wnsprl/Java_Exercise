package product.run;
import product.model.vo.Product;

public class TestProduct {
	public static void main(String[] args) {
		Product tv= new Product();
		
		tv.printProduct();
	}
}
